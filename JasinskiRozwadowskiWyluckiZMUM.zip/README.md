pip install gymnasium
pip install box2d pygame